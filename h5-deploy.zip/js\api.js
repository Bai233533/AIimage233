/**
 * api.js - 后端 API 调用封装（纯 fetch，不依赖 CloudBase SDK）
 * 部署到 Vercel 后，通过 CloudBase HTTP 访问服务调用 h5Backend 云函数
 *
 * 配置步骤：
 * 1. CloudBase 控制台 → HTTP 访问服务 → 开启服务
 * 2. 添加路由：路径 /api，资源类型"云函数"，资源对象 h5Backend，开启路径透传
 * 3. 将下方 API_BASE_URL 替换为你的 HTTP 访问服务默认域名
 */

// ====== API 基础地址 ======
// 部署后替换为你的 CloudBase HTTP 访问服务地址
// 格式：https://<env-id>.service.tcloudbaseapp.com/api
const API_BASE_URL = 'https://cloud1-d4g2fqiz8adfe4863.service.tcloudbaseapp.com/api';

const API = {

  // ==================== 调用云函数（核心方法） ====================
  async callFunction(action, data) {
    try {
      const res = await fetch(API_BASE_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action, ...data })
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }

      const result = await res.json();

      if (result.code && result.code !== 0 && result.code !== 200) {
        throw new Error(result.message || '云函数返回错误');
      }

      return result.data || result;
    } catch (err) {
      console.error('[API 调用失败]', action, err);

      // 如果是网络错误，给出更友好的提示
      if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
        throw new Error('网络连接失败，请检查网络后重试');
      }

      throw err;
    }
  },

  // ==================== AI: 生成分镜提示词（图片识别） ====================
  // images: base64 字符串数组（不含 data:image 前缀）
  async generatePrompt(images, userPrompt, count) {
    return await this.callFunction('generatePrompt', { images, userPrompt, count });
  },

  // ==================== AI: 纯文字生成分镜提示词 ====================
  async generatePromptFromText(userPrompt, count) {
    return await this.callFunction('generatePromptFromText', { userPrompt, count });
  },

  // ==================== AI: 生成图片 ====================
  // images: base64 数组（产品图+参考图合并），referenceImages: 参考图数量
  async generateImage(prompt, count, images, referenceCount) {
    return await this.callFunction('generateImage', {
      prompt,
      count,
      images: images || [],
      referenceImages: referenceCount || 0
    });
  },

  // ==================== AI: 纯文字对话 ====================
  async chat(messages, systemPrompt) {
    return await this.callFunction('chat', { messages, systemPrompt });
  },

  // ==================== 用户: 登录 ====================
  async login(username, password) {
    return await this.callFunction('login', { username, password });
  },

  // ==================== 用户: 注册 ====================
  async register(username, password) {
    return await this.callFunction('register', { username, password });
  },

  // ==================== 用户: 检查会员状态 ====================
  async checkMembership(username) {
    return await this.callFunction('checkMembership', { username });
  },

  // ==================== 用户: 卡密兑换 ====================
  async verifyCardKey(username, cardKey) {
    return await this.callFunction('verifyCardKey', { username, cardKey });
  },

  // ==================== 文本安全检查 ====================
  async textSecurityCheck(content) {
    return await this.callFunction('textSecurityCheck', { content });
  },

  // ==================== 图片意图检测（前端逻辑，同小程序） ====================
  detectImageIntent(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    const keywords = [
      '分镜', '画面', '场景', '背景', '镜头', '景别',
      '特写', '全景', '近景', '远景', '俯拍', '仰拍',
      '竖屏', '横屏', '9:16', '16:9', '4:3',
      '色调', '光影', '氛围', '风格', '画风',
      '生成', '生图', '出图', '画一张', '帮我画',
      '动漫', '插画', '3D', '写实', '水彩', '像素',
      '人物', '角色', '产品', '商品', '食物', '风景',
      '背景虚化', '逆光', '暖色', '冷色', '霓虹'
    ];
    return keywords.some(kw => lower.includes(kw));
  }
};
